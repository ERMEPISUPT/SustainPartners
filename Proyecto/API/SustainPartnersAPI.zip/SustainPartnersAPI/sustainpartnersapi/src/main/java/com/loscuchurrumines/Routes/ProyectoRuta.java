package com.loscuchurrumines.Routes;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.loscuchurrumines.DAO.ProyectoDAO;
import com.loscuchurrumines.Model.Proyecto;

@RestController
@RequestMapping("/proyectos")
public class ProyectoRuta {
    ProyectoDAO proyectoDAO = new ProyectoDAO();
    @GetMapping
    public List<Proyecto> getProyectos(){
        return proyectoDAO.obtenerProyectos();

    
    }
    
}
