package com.loscuchurrumines.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.loscuchurrumines.Config.NeonConnection;
import com.loscuchurrumines.Model.Proyecto;

public class ProyectoDAO {

    public List<Proyecto> obtenerProyectos() {
        List<Proyecto> proyectos = new ArrayList<Proyecto>();
        Connection connection = NeonConnection.getConnection();
        PreparedStatement statement;
        ResultSet resultSet;
        String query = "SELECT * FROM tbproyecto";
        try {
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Proyecto proyecto = new Proyecto();
                proyecto.setIdProyecto(resultSet.getInt("idproyecto"));
                proyecto.setNombre(resultSet.getString("nombre"));
                proyecto.setDescripcion(resultSet.getString("descripcion"));
                proyecto.setObjetivo(resultSet.getString("objetivo"));
                proyecto.setFoto(resultSet.getString("foto"));
                proyecto.setEstado(resultSet.getBoolean("estado"));
                proyecto.setFkRegion(resultSet.getInt("fkregion"));
                proyecto.setFkUser(resultSet.getInt("fkuser"));
                proyecto.setFkFondo(resultSet.getInt("fkfondo"));
                proyectos.add(proyecto);
            }
            return proyectos;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;

    }
    
}
